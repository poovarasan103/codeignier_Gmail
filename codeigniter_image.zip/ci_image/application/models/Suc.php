<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Suc extends CI_Model{
function __construct() {
parent::__construct();
	$this->load->helper(array('url','form','file'));
$this->load->database();

}


function insert_data()
{


$n="$this->upload->data('file_name')";
$p="$this->upload->data('full_path')";
$t="$this->upload->data('file_type')";
$s="$this->upload->data('file_size')";
$e="$this->upload->data('file_ext')";
                            
 

$dat = "INSERT INTO files VALUES ('$n','$p','$t','$s','$e');";
                            
$this->db->query($dat);




}



}