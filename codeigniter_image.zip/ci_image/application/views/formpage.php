<html>
<head>
<title>Image uploading form</title>

</head>
<body>
<center>	<h2>Uploading a file to Database</h2>
	<?php echo $error;?>
<div>	
<?php echo form_open_multipart('image/upl');?>
<input type="file" name="images">

<input type="submit" value="upload" >
<?php echo form_close();?></div>
</center></body>
</html>