<html>
<head>
<title>Success</title>

</head>
<body>

	<h2> Your file <span style="color:red"><?php echo $this->upload->data('file_name');?></span> Uploaded Successfully</h2>



<?php foreach ($upload_data as $item => $value):?>
<p><?php echo $item;?> : <?php echo $value;?><br></p>
<?php endforeach; ?>
<br><br>
<h3><?php echo anchor('image', 'Upload Another File!'); ?></h3>

</body>
</html>