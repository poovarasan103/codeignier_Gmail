<?php
class Image extends CI_Controller {
	 public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
        }

            
        public function index(){
            $this->load->view('formpage',array('err' => ' ' ));
        }
        public function upl(){
        	$cnf['upload_path']='./upfiles/';
        	$cnf['max_size']='5000';
        	$cnf['min_height']='200';
        	$cnf['min_width']='200';
        	$cnf['max_height']='800';
        	$cnf['max_width']='1000';
        	$cnf['allowed_types']='jpg|jpeg';
        	$this->load->library('upload',$cnf);
        	if ($this->upload->do_upload('images'))
                {
                	 $data = array('upload_data' => $this->upload->data());
                       

                        $this->load->view('imguploaded', $data);

$n=$this->upload->data('file_name');
$p=$this->upload->data('full_path');
$t=$this->upload->data('file_type');
$s=$this->upload->data('file_size');
$e=$this->upload->data('file_ext');
                            
 $this->load->database();

$dat = "INSERT INTO images VALUES ('$n','$p','$t','$s','$e');";
                            
$this->db->query($dat);
                        
                      
                }
                else
                {
                       
                        $error = array('error' => $this->upload->display_errors());

                        $this->load->view('formpage', $error);

                }


        }

}
